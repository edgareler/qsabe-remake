
window.onload = function() {
    $(function() {
        var chart;

        $(document).ready(function() {

            // Build the chart
            $('#chart-01').highcharts({
                chart: {
                    plotBackgroundColor: null,
                    plotBorderWidth: null,
                    backgroundColor: 'rgba(255, 255, 255, 0)',
                    plotShadow: false
                },
                tooltip: {
                    pointFormat: '<b>{point.percentage:.1f}%</b>'
                },
                title: {
                    text: 'Questionador'
                },
                plotOptions: {
                    pie: {
                        allowPointSelect: true,
                        cursor: 'pointer',
                        dataLabels: {
                            enabled: false
                        },
                        showInLegend: true
                    }
                },
                series: [{
                        type: 'pie',
                        name: '',
                        data: [
                            ['Perguntas', 133],
                            ['Respostas', 45]
                        ]
                    }]
            });
        });

    });
};