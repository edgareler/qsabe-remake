@extends('layout')

@section('title')
Usuários @stop

@section('content')
    Usuários do QSabe! AICV!!!!!!!!!!!!!!!!
@stop