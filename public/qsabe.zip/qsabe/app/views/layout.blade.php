<!DOCTYPE html>
<html>
    <head>
        <title>QSabe - @yield('title','O que você deseja saber agora?')</title>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="icon" type="image/png" href="/img/icon.png" />
        <!--<link href="http://fonts.googleapis.com/css?family=Ubuntu:400,700,400italic,700italic" rel="stylesheet" type="text/css" />-->
        <link href="/css/bootstrap-wysihtml5.css" rel="stylesheet" type="text/css" />
        <link href="/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="/css/qsabe.css" rel="stylesheet" type="text/css" />
        @yield('head')
    </head>
    <body>
        <header>
            <div id="logo">
                <img src="/img/logo.png" width="126" height="32" alt="QSabe" />
            </div>

            <div class="form-group" id="search">
                <div class="input-group">
                    <input class="form-control" type="search" placeholder="O que você deseja saber agora?" />
                    <div class="input-group-btn">
                        <button type="submit" class="btn btn-default"><span class="glyphicon glyphicon-search"></span></button>
                    </div>
                </div>
            </div>
        </header>

        <div id="main">
            <div id="left">
                <div class="box">
                    <div class="title qsabeicon qsabeicon-contextos">
                        Contextos
                    </div>
                    <a href="#" class="bg-verde-escuro qsabeicon qsabeicon-informatica-l bt-context">
                        Informática
                    </a>
                    <a href="#" class="bg-vermelho-escuro qsabeicon qsabeicon-quimica-l bt-context">
                        Química
                    </a>
                    <a href="#" class="bg-azul-claro qsabeicon qsabeicon-fisica-l bt-context">
                        Física
                    </a>
                    <a href="#" class="bg-azul-escuro qsabeicon qsabeicon-astronomia-l bt-context">
                        Astronomia
                    </a>
                    <a href="#" class="bg-ouro qsabeicon qsabeicon-fotografia-l bt-context">
                        Fotografia
                    </a>
                    <a href="#" class="bg-verde-claro qsabeicon qsabeicon-jogos-l bt-context">
                        Jogos
                    </a>
                </div>
                <div class="box">
                    <div class="title qsabeicon qsabeicon-desempenho">
                        Desempenho
                    </div>
                    <div id="chart-01" class="chart"></div>
                </div>
            </div>

            <div id="content">
                <nav>
                    <ul id="abas" class="nav nav-tabs" role="tablist">
                        <li class="active"><a href="#novas-respostas" role="tab" data-toggle="tab" class="verde qsabeicon qsabeicon-respostas">Novas Respostas</a></li>
                        <li><a href="#minhas-perguntas" role="tab" data-toggle="tab" class="vermelho qsabeicon qsabeicon-minhas-perguntas">Minhas Perguntas</a></li>
                        <li><a href="#perguntas-responder" role="tab" data-toggle="tab" class="ouro qsabeicon qsabeicon-perguntas-responder">Perguntas a Responder</a></li>
                    </ul>
                    <div id="abas-content" class="tab-content">
                        <div class="tab-pane fade in active" id="novas-respostas">
                            <div class="pergunta">
                                <div class="count-respostas bg-verde-escuro">
                                    <span>1</span>resposta
                                </div>
                                <a href="#" class="texto-pergunta">
                                    Praesent libero magna, dapibus sollicitudin nisi id, suscipit congue odio Nunc lobortis semper arcu, non pellentesque diam, Nulla fermentum libero vel nunc?
                                </a>
                                <a href="#" class="context-small verde-escuro qsabeicon qsabeicon-android-s">Android</a>
                                <a href="#" class="context-small ouro qsabeicon qsabeicon-criptografia-s">Criptografia</a>
                            </div>

                            <div class="pergunta bg-branco-gelo">
                                <div class="count-respostas bg-verde-escuro">
                                    <span>1</span>resposta
                                </div>
                                <a href="#" class="texto-pergunta">
                                    Suspendisse consequat sit amet risus eu varius?
                                </a>
                                <a href="#" class="context-small azul-claro qsabeicon qsabeicon-fisica-s">Física</a>
                            </div>

                            <div class="pergunta">
                                <div class="count-respostas bg-verde-escuro">
                                    <span>1</span>resposta
                                </div>
                                <a href="#" class="texto-pergunta">
                                    Maecenas libero dolor, placerat quis mauris lobortis, ornare pulvinar magna?
                                </a>
                                <a href="#" class="context-small laranja qsabeicon qsabeicon-eletricidade-s">Elétrica</a>
                                <a href="#" class="context-small azul-claro qsabeicon qsabeicon-fisica-s">Física</a>
                            </div>

                            <div class="pergunta bg-branco-gelo">
                                <div class="count-respostas bg-verde-escuro">
                                    <span>1</span>resposta
                                </div>
                                <a href="#" class="texto-pergunta">
                                    Fusce ipsum quam, pulvinar et risus non, vulputate egestas nibh, vivamus consequat?
                                </a>
                                <a href="#" class="context-small azul-petroleo qsabeicon qsabeicon-contabilidade-s">Contabilidade</a>
                            </div>

                            <div class="pergunta">
                                <div class="count-respostas bg-verde-escuro">
                                    <span>1</span>resposta
                                </div>
                                <a href="#" class="texto-pergunta">
                                    Phasellus id arcu vitae magna consectetur sodales at ac sapien?
                                </a>
                                <a href="#" class="context-small ouro qsabeicon qsabeicon-criptografia-s">Criptografia</a>
                            </div>

                            <div class="pergunta bg-branco-gelo">
                                <div class="count-respostas bg-verde-escuro">
                                    <span>1</span>resposta
                                </div>
                                <a href="#" class="texto-pergunta">
                                    Suspendisse consequat sit amet risus eu varius?
                                </a>
                                <a href="#" class="context-small azul-claro qsabeicon qsabeicon-fisica-s">Física</a>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="minhas-perguntas">
                            <div class="pergunta">
                                <div class="count-respostas">
                                    <span>0</span>respostas
                                </div>
                                <a href="#" class="texto-pergunta">
                                    Praesent libero magna, dapibus sollicitudin nisi id, suscipit congue odio Nunc lobortis semper arcu, non pellentesque diam, Nulla fermentum libero vel nunc?
                                </a>
                                <a href="#" class="context-small verde-escuro qsabeicon qsabeicon-android-s">Android</a>
                                <a href="#" class="context-small ouro qsabeicon qsabeicon-criptografia-s">Criptografia</a>
                            </div>

                            <div class="pergunta bg-branco-gelo">
                                <div class="count-respostas bg-verde-escuro">
                                    <span>1</span>resposta
                                </div>
                                <a href="#" class="texto-pergunta">
                                    Suspendisse consequat sit amet risus eu varius?
                                </a>
                                <a href="#" class="context-small azul-claro qsabeicon qsabeicon-fisica-s">Física</a>
                            </div>

                            <div class="pergunta">
                                <div class="count-respostas">
                                    <span>0</span>respostas
                                </div>
                                <a href="#" class="texto-pergunta">
                                    Maecenas libero dolor, placerat quis mauris lobortis, ornare pulvinar magna?
                                </a>
                                <a href="#" class="context-small laranja qsabeicon qsabeicon-eletricidade-s">Elétrica</a>
                                <a href="#" class="context-small azul-claro qsabeicon qsabeicon-fisica-s">Física</a>
                            </div>

                            <div class="pergunta bg-branco-gelo">
                                <div class="count-respostas">
                                    <span>0</span>respostas
                                </div>
                                <a href="#" class="texto-pergunta">
                                    Fusce ipsum quam, pulvinar et risus non, vulputate egestas nibh, vivamus consequat?
                                </a>
                                <a href="#" class="context-small azul-petroleo qsabeicon qsabeicon-contabilidade-s">Contabilidade</a>
                            </div>

                            <div class="pergunta">
                                <div class="count-respostas">
                                    <span>0</span>respostas
                                </div>
                                <a href="#" class="texto-pergunta">
                                    Phasellus id arcu vitae magna consectetur sodales at ac sapien?
                                </a>
                                <a href="#" class="context-small ouro qsabeicon qsabeicon-criptografia-s">Criptografia</a>
                            </div>

                            <div class="pergunta bg-branco-gelo">
                                <div class="count-respostas bg-verde-escuro">
                                    <span>12</span>respostas
                                </div>
                                <a href="#" class="texto-pergunta">
                                    Suspendisse consequat sit amet risus eu varius?
                                </a>
                                <a href="#" class="context-small azul-claro qsabeicon qsabeicon-fisica-s">Física</a>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="perguntas-responder">
                            <div class="pergunta">
                                <div class="count-respostas bg-verde-escuro">
                                    <span>1</span>resposta
                                </div>
                                <a href="#" class="texto-pergunta">
                                    Praesent libero magna, dapibus sollicitudin nisi id, suscipit congue odio Nunc lobortis semper arcu, non pellentesque diam, Nulla fermentum libero vel nunc?
                                </a>
                                <a href="#" class="context-small verde-escuro qsabeicon qsabeicon-android-s">Android</a>
                                <a href="#" class="context-small ouro qsabeicon qsabeicon-criptografia-s">Criptografia</a>
                            </div>

                            <div class="pergunta bg-branco-gelo">
                                <div class="count-respostas">
                                    <span>0</span>respostas
                                </div>
                                <a href="#" class="texto-pergunta">
                                    Suspendisse consequat sit amet risus eu varius?
                                </a>
                                <a href="#" class="context-small azul-claro qsabeicon qsabeicon-fisica-s">Física</a>
                            </div>

                            <div class="pergunta">
                                <div class="count-respostas">
                                    <span>0</span>respostas
                                </div>
                                <a href="#" class="texto-pergunta">
                                    Maecenas libero dolor, placerat quis mauris lobortis, ornare pulvinar magna?
                                </a>
                                <a href="#" class="context-small laranja qsabeicon qsabeicon-eletricidade-s">Elétrica</a>
                                <a href="#" class="context-small azul-claro qsabeicon qsabeicon-fisica-s">Física</a>
                            </div>

                            <div class="pergunta bg-branco-gelo">
                                <div class="count-respostas bg-verde-escuro">
                                    <span>1</span>resposta
                                </div>
                                <a href="#" class="texto-pergunta">
                                    Fusce ipsum quam, pulvinar et risus non, vulputate egestas nibh, vivamus consequat?
                                </a>
                                <a href="#" class="context-small azul-petroleo qsabeicon qsabeicon-contabilidade-s">Contabilidade</a>
                            </div>

                            <div class="pergunta">
                                <div class="count-respostas">
                                    <span>0</span>respostas
                                </div>
                                <a href="#" class="texto-pergunta">
                                    Phasellus id arcu vitae magna consectetur sodales at ac sapien?
                                </a>
                                <a href="#" class="context-small ouro qsabeicon qsabeicon-criptografia-s">Criptografia</a>
                            </div>

                            <div class="pergunta bg-branco-gelo">
                                <div class="count-respostas bg-verde-escuro">
                                    <span>2</span>respostas
                                </div>
                                <a href="#" class="texto-pergunta">
                                    Suspendisse consequat sit amet risus eu varius?
                                </a>
                                <a href="#" class="context-small azul-claro qsabeicon qsabeicon-fisica-s">Física</a>
                            </div>
                        </div>

                    </div>
                </nav>

                <div id="nova-pergunta" class="box">
                    <div id="nova-pergunta-content">
                        <div class="title qsabeicon qsabeicon-nova-pergunta">Enviar Nova Pergunta</div>

                        <form class="form-horizontal" role="form">
                            <div class="form-group">
                                <label for="inputPergunta" class="col-sm-1 control-label label-pergunta">Título:</label>
                                <div class="col-sm-11">
                                    <input type="search" class="form-control" id="inputPergunta" placeholder="Insira sua nova pergunta">
                                </div>
                            </div>
                            
                            <div class="form-group form-textarea">
                                <textarea class="form-control textarea" id="text-pergunta" rows="3"></textarea>
                            </div>
                            
                            <div class="form-group">
                                <button type="submit" class="btn btn-success"><span class="glyphicon glyphicon-ok"></span> Enviar</button>
                            </div>
                        </form>
                    </div>

                    <div id="perguntas-semelhantes" class="box bg-branco-gelo">
                        <div class="title-no-icon">Perguntas Semelhantes</div>
                        <a href="#">Suspendisse consequat sit amet risuseu varius?</a>
                        <a href="#">Maecenas libero dolor, placerat quismauris lobortis ornare pulvinar magna?</a>
                        <a href="#">Suspendisse consequat sit amet risuseu varius?</a>
                        <a href="#">Suspendisse consequat sit amet risuseu varius?</a>
                        <a href="#">Suspendisse consequat sit amet risuseu varius?</a>
                        <a href="#">Suspendisse consequat sit amet risuseu varius?</a>
                    </div>
                </div>
                @yield('content')
            </div>

            <div id="right">

            </div>
        </div>

        <!-- Bootstrap core JavaScript
        ================================================== -->
        <!-- Placed at the end of the document so the pages load faster -->
        <script src="/js/wysihtml5-0.3.0.min.js"></script>
        <script src="/js/jquery-2.1.1.min.js"></script>
        <script src="/js/jquery.placeholder.js"></script>
        <script src="/js/bootstrap.min.js"></script>
        <script src="/js/bootstrap3-wysihtml5.js"></script>
        <script src="/locales/bootstrap-wysihtml5.pt-BR.js"></script>
        <script src="/js/highcharts.js"></script>
        
        <script src="/js/qsabe.js"></script>

        <script>
            $(function() {
                $('input, textarea').placeholder();
            });

            $('#abas a').click(function(e) {
                e.preventDefault();
                $(this).tab('show');
            });

            $('.textarea').wysihtml5();
        </script>
    </body>
</html>